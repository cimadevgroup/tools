import { $, $$, getLocalDateTime, fmtDateTime, STATE, generateServiceId } from 'brain';
import { updateRecipeTextbox, renderIndicacionesDropdowns } from './documents.js';
// IMPORTANTE: Importamos ServiceLoader para leer datos del paciente para la herencia
import { ServiceLoader } from '../../../../logic/service_loader.js';

// ==========================================
// 1. ESTILOS PROPIOS
// ==========================================
const STYLES = `
<style>
    /* Estilos base de la tarjeta */
    .visit-card {
        background: var(--glass-bg);
        border: 1px solid var(--glass-border);
        border-radius: 16px;
        padding: 0;
        margin-bottom: 20px;
        overflow: hidden;
        backdrop-filter: blur(var(--blur-strength));
        box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .visit-card:hover {
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    }

    /* Header de la tarjeta */
    .visit-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px 20px;
        background: rgba(255, 255, 255, 0.03);
        border-bottom: 1px solid var(--glass-border);
        cursor: pointer;
        user-select: none;
    }
    .visit-header:hover {
        background: rgba(255, 255, 255, 0.07);
    }
    
    /* Cuerpo de la tarjeta */
    .visit-body {
        padding: 20px;
        animation: slideDown 0.3s ease-out;
    }
    @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }

    /* Areas de Examen Físico */
    .exam-area {
        background: rgba(0, 0, 0, 0.2);
        border: 1px solid var(--glass-border);
        border-radius: 8px;
        padding: 12px;
        margin-bottom: 12px;
    }
    .exam-area-title {
        color: var(--accent);
        font-size: 0.85rem;
        font-weight: 700;
        text-transform: uppercase;
        margin-bottom: 8px;
        display: flex; align-items: center; gap: 6px;
    }

    /* Chips */
    .chip-group { margin-bottom: 5px; }
    .chip-group-title { font-size: 0.75rem; color: var(--text-muted); margin-bottom: 4px; }
    
    .chip {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 20px;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid var(--glass-border);
        font-size: 0.8rem;
        cursor: pointer;
        margin: 2px;
        transition: all 0.2s;
        color: var(--text-main);
    }
    .chip:hover { border-color: var(--primary); color: white; }
    .chip.on {
        background: var(--primary);
        border-color: var(--primary);
        color: white;
        font-weight: 600;
        box-shadow: 0 0 10px var(--primary);
    }
    .chip.study-chip { border-color: var(--accent); color: var(--accent); }
    .chip.study-chip.on { background: var(--accent); color: black; }

    .patient-nav {
        display: flex; justify-content: flex-end; gap: 10px;
        padding-top: 15px; margin-top: 10px;
        border-top: 1px solid var(--glass-border);
    }
    
    .visit-toggle-btn {
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: #94a3b8;
        border-radius: 6px;
        padding: 4px 8px;
        cursor: pointer;
        transition: all 0.2s;
        font-size: 0.75rem;
    }
    .visit-toggle-btn:hover { background: rgba(255, 255, 255, 0.1); color: white; }
</style>
`;

// ==========================================
// 2. DATA (CONFIGURACIÓN MÉDICA)
// ==========================================
export const CIMA_DATA = {
  MOTIVOS: ["Obstrucción Nasal","Ronquidos Nocturnos","Respiración Bucal","Rinorrea","Odinofagia","Otorrea","Otalgia","Masa en Cuello","Difonía","Dolor Facial","Cefalea"],
  ANTECEDENTES: ["Alergias","Asma","HTA","Tiroides","DM","IQx","Trauma Acústico"],
  DX: ["Otocerumen Bilateral","Otocerumen Derecho","Otocerumen Izquierdo","Otitis Externa Bilateral","Otitis Externa Derecha","Otitis Externa Izquierda","Otitis Media Aguda Bilateral","Otitis Media Aguda Derecha","Otitis Media Aguda Izquierda","Otitis Media Crónica Perforada Bilateral","Otitis Media Crónica Perforada Derecha","Otitis Media Crónica Perforada Izquierda","Otitis Media Crónica Sucurativa","Otitis Media Crónica Colestetomatosa","Hipoacusia Neurosensorial Profunda Bilateral","Hipoacusia Neurosensorial Profunda Derecha","Hipoacusia Neurosensorial Profunda Izquierda","Hipoacusia Conductiva Leve Bilateral","Hipoacusia Conductiva Leve Derecha","Hipoacusia Conductiva Leve Izquierda","Presbiacusia","Otitis Media Serosa Bilateral","Otitis Media Serosa Derecha","Otitis Media Serosa Izquierda","Faringoamigdalitis Aguda","Tonsilitis Recurrente","Otitis Media Aguda Recurrente","Alto Riesgo Biológico Para Hipoacusia","Rinopatía Obstructiva","Rinitis Alérgica","Poliposis Nasal","Rinosinusitis Aguda Maxiloetmoidal","Rinosinusitis Aguda Maxilar","Rinosinusitis Maxilar Crónica","Rinosinusitis Crónica Con Poliposis Nasal","Lesión En Cuerda Vocal Derecha","Lesión En Cuerda Vocal Izquierda","Parálisis De Cuerda Vocal Bilateral","Parálisis De Cuerda Vocal Derecha","Parálisis De Cuerda Vocal Izquierda","Epistaxis Anterior","Epistaxis Anteroposterior","Epistaxis Posterior","Frenillo Lingual","Antecedente Quirúrgico"],
  RECIPE_MEDS: {
    "Esteroides Nasales": ["Solución Fisiológica","Flinas / Nasonex / Elocon / Flixonase / Nimarin / Budenas (Spray Nasal)","Flinas - Spray Nasal","Nasonex - Spray Nasal","Elocon - Spray Nasal","Flixonase - Spray Nasal","Nimarin - Spray Nasal","Budenas - Spray Nasal","Momentasona o Fluticasona - Spray Nasal"],
    "Antialérgicos": ["Desloratadina - Tabletas 5 mg","Desloratadina - Jarabe","Loratadina - Tabletas 10 mg","Loratadina - Jarabe","Cetirizina - Tabletas 10 mg","Cetirizina - Jarabe","Levocetirizina - Tabletas 5 mg","Levocetirizina - Jarabe","Rinolast - Tabletas","Rinolast - Jarabe","Fexofenadina - Tabletas 120 mg","Fexofenadina - Jarabe","Claricort - Tabletas","Lorecort - Jarabe","Montelukast - Tabletas 4 mg","Montelukast - Tabletas 5 mg","Montelukast - Tabletas 10 mg","Rinomax - Gotas Nasales","Bactroban, Bacitracina, Mupirocina, Muprovan - crema o ungüento"],
    "Gotas óticas": ["Quinotic, Quinotic HC, (Gotas Óticas)","Otalex (Gotas Óticas)","Poliótico (Gotas Óticas)","Otirilin o Aceite de Bebé (Gotas)"],
    "Protector Gástrico": ["Pantoprazol ó Esomeprazol - Tabletas de 20 mg","Pantoprazol - Tabletas 40 mg"],
    "Antibióticos": ["Amoxicilina / Acido Clavulánico - Tabletas 875/125 mg","Amoxicilina / Acido Clavulánico - Suspensión 600 mg / 5 ml","Amoxicilina - Tabletas 500 mg","Amoxicilina - Jarabe","Sultamicilina - Tabletas 750 mg","Sultamicilina - Suspensión 250 mg / 5 ml","Levofloxacina- Tabletas 500 mg","Levofloxacina- Tabletas 750 mg","Moxifloxacina, Moxen, Avelox - Comprimidos 400 mg"],
    "Otros": ["Pulmolix - Sobres","Betahistina - 8 mg","Betahistina - 16 mg","Betahistina - 24 mg","Viajesan - Comprimidos"]
  },
  INDICACIONES_OPTIONS: {
    "Esteroides Nasales": ["Realizar lavados nasales cada 12 horas por 7 días.","Colocar dos aplicaciones en cada fosa nasal cada 12 horas por 1 mes.","Colocar una aplicación en cada fosa nasal cada 12 horas por 1 mes."],
    "Antialérgicos": ["Tomar 1 tableta diaria por 1 mes.","Dar vía oral 1 cc una vez al día por 1 mes.","Dar vía oral 2 cc una vez al día por 1 mes.","Dar vía oral 3 cc una vez al día por 1 mes.","Dar vía oral 4 cc una vez al día por 1 mes.","Dar vía oral 5 cc una vez al día por 1 mes.","Tomar 1 tableta cada 12 horas por 7 días.","Dar vía oral 1 cc cada 12 horas por 7 días.","Dar vía oral 2 cc cada 12 horas por 7 días.","Dar vía oral 3 cc cada 12 horas por 7 días.","Dar vía oral 4 cc cada 12 horas por 7 días.","Dar vía oral 5 cc cada 12 horas por 7 días.","Colocar 3 Gotas en cada fosa nasal cada 8 horas por 5 días.","Colocar 1 aplicación en cada fosa nasal cada 12 horas por 7 días.","Tomar 1 tableta diaria por 3 meses."],
    "Gotas óticas": ["Aplicar 3 Gotas en cada oído cada 12 horas por 7 días. No mojar los oídos.","Aplicar 3 Gotas en cada oído cada 8 horas por 7 días. No mojar los oídos.","Aplicar 3 Gotas en oído izquierdo cada 8 horas por 7 días. No mojar los oídos.","Aplicar 3 Gotas en oído izquierdo cada 12 horas por 7 días. No mojar los oídos.","Aplicar 3 Gotas en oído derecho cada 8 horas por 7 días. No mojar los oídos.","Aplicar 3 Gotas en oído derecho cada 12 horas por 7 días. No mojar los oídos."],
    "Protector Gástrico": ["Tomar 1 tableta diaria por 3 meses.","Tomar 1 tableta diaria antes del desayuno por 1 mes.","Tomar 1 tableta antes del desayuno y 1 Tableta antes la cena por 1 mes."],
    "Antibióticos": ["Tomar 1 tableta cada 12 horas por 10 días.","Tomar 1 tableta cada 8 horas por 10 días.","Tomar 1 tableta diaria por 10 días.","Dar vía oral 1 cc cada 12 horas por 10 días.","Dar vía oral 2 cc cada 12 horas por 10 días.","Dar vía oral 3 cc cada 12 horas por 10 días.","Dar vía oral 4 cc cada 12 horas por 10 días.","Dar vía oral 5 cc cada 12 horas por 10 días.","Dar vía oral 6 cc cada 12 horas por 10 días."],
    "Otros": ["Tomar 1 tableta cada 12 horas por 10 días.","Tomar 1 tableta cada 8 horas por 10 días.","Tomar 1 tableta diaria por 10 días."]
  },
  STUDIES: {
    "Nasofibrolaringoscopia": {
      "Fosas Nasales": ["Permeables","No Permeables"],
      "Correderas Nasales": ["Sin Rinorrea","Rinorrea Blanca Escasa","Rinorrea Blanca Moderada","Rinorrea Blanca Abundante","Rinorrea Hialina Escasa","Rinorrea Hialina Moderada","Rinorrea Hialina Abundante","Rinorrea Amarilla Escasa","Rinorrea Amarilla Moderada","Rinorrea Amarilla Abundante","Rinorrea Verde Escasa","Rinorrea Verde Moderada","Rinorrea Verde Abundante"],
      "Tabique": ["Central","Septumdesviación Levoconvexa","Septumdesviación Dextroconvexa","Levoconvexa Con Espolón Oseo Derecho","Levoconvexa Con Espolón Oseo Izquierdo","Dextroconvexa Con Espolón Oseo Derecho","Dextroconvexa Con Espolón Oseo Izquierdo","Central Con Espolón Óseo Derecho","Central Con Espolón Óseo Izquierdo"],
      "Cornete Inferior Derecho": ["Eutrófico","Hipertrófico","Polipoide"],
      "Cornete Medio Derecho": ["Eutrófico","Hipertrófico","Polipoide"],
      "Meato Medio Derecho": ["Libre","Comprometido"],
      "Coana Derecha": ["Permeable","No Permeable"],
      "Cornete Inferior Izquierdo": ["Eutrófico","Hipertrófico","Polipoide"],
      "Cornete Medio Izquierdo": ["Eutrófico","Hipertrófico","Polipoide"],
      "Meato Medio Izquierdo": ["Libre","Comprometido"],
      "Coana Izquierda": ["Permeable","No Permeable"],
      "Paladar": ["Con Cierre Coronal","Competente","Incompetente"],
      "Adenoides": ["Ausentes","Leves","Moderadas","Severas"],
      "Rinofaringe": ["Indemne","Congestiva Granulosa","Granulosa","Con Rinorrea Posterior Blanca Escasa","Con Rinorrea Posterior Hialina Escasa","Con Rinorrea Posterior Amarilla Escasa","Con Rinorrea Posterior Verde Escasa","Con Rinorrea Posterior Blanca Moderada","Con Rinorrea Posterior Hialina Moderada","Con Rinorrea Posterior Amarilla Moderada","Con Rinorrea Posterior Verde Moderada","Con Rinorrea Posterior Blanca Abundante","Con Rinorrea Posterior Hialina Abundante","Con Rinorrea Posterior Amarilla Abundante","Con Rinorrea Posterior Verde Abundante"],
      "Base De Lengua": ["Sin Lesiones","Con Loe"],
      "Senos Piriformes": ["Indemnes","Seno Piriforme Derecho Con Loe","Seno Piriforme Derecho Sin Lesiones","Seno Piriforme Izquierdo Con Loe","Seno Piriforme Izquierdo Sin Lesiones"],
      "Valleculas": ["Indemnes","Vallecula Derecha Con Loe","Vallecula Derecha Sin Lesiones","Vallecula Izquierda Con Loe","Vallecula Izquierda Sin Lesiones"],
      "Epiglotis": ["Indemne Erecta","Móvil","Eritematosa","En Omega"],
      "Bandas Ventriculares": ["Indemnes","Hipertróficas","Con Loe"],
      "Cuerda Vocal Derecha": ["Indemne","Indemne Móvil","Móvil Con Loe","Móvil Con Leucoplasia","Inmóvil Con Loe","Inmóvil Con Leucoplasia"],
      "Cuerda Vocal Izquierda": ["Indemne","Indemne Móvil","Móvil Con Loe","Móvil Con Leucoplasia","Inmóvil Con Loe","Inmóvil Con Leucoplasia"],
      "Cierre Glótico": ["Completo","Incompleto En Huso","Incompleto Irregular","En Reloj De Arena","Con Hiato Anterior","Con Hiato Posterior"],
      "Subglotis": ["Permeable 100%","Estenosis Subglótica Cotton I","Estenosis Subglótica Cotton Ii","Estenosis Subglótica Cotton Iii"],
      "Mucosa": ["Indemne","Eritematosa","Pálida","Con Plexo Derecho Friable","Con Plexo Izquierdo Friable"]
    },
    "Endoscopia Nasal": {
      "Fosas Nasales": ["Permeables","No Permeables"],
      "Tabique": ["Central","Septumdesviación Levoconvexa","Septumdesviación Dextroconvexa","Levoconvexa Con Espolón Oseo Derecho","Levoconvexa Con Espolón Oseo Izquierdo","Dextroconvexa Con Espolón Oseo Derecho","Dextroconvexa Con Espolón Oseo Izquierdo","Central Con Espolón Óseo Derecho","Central Con Espolón Óseo Izquierdo"],
      "Cornete Medio Derecho": ["Eutrófico","Hipertrófico","Polipoide","Concha Media Bullosa Derecha","Paradójico Derecho"],
      "Cornete Medio Izquierdo": ["Eutrófico","Hipertrófico","Polipoide","Concha Media Bullosa Izquierda","Paradójico Izquierdo"],
      "Meato Medio Derecho": ["Libre","Comprometido"],
      "Meato Medio Izquierdo": ["Libre","Comprometido"],
      "Coana Derecha": ["Permeable","No Permeable"],
      "Coana Izquierda": ["Permeable","No Permeable"],
      "Sinusopatía": ["Sin Sinusopatía","Con Sinusopatía Maxilar Derecha","Con Sinusopatía Maxilar Izquierda","Con Sinusopatía Frontal Derecha","Con Sinusopatía Frontal Izquierda","Con Sinusopatía Etmoidal Anterior Derecha","Con Sinusopatía Etmoidal Anterior Izquierda","Con Sinusopatía Etmoidal Posterior Derecha","Con Sinusopatía Etmoidal Posterior Izquierda","Con Sinusopatía Esfenoidal Anterior Derecha","Con Sinusopatía Esfenoidal Anterior Izquierda","Con Sinusopatía Maxiloetmoidal Derecha","Con Sinusopatía Maxiloetmoidal Izquierda"]
    },
    "Telelaringoscopia": {
      "Cierre Glótico": ["Completo","Incompleto En Huso","Incompleto Irregular","En Reloj De Arena","Con Hiato Anterior","Con Hiato Posterior"],
      "Bandas Ventriculares": ["Indemnes","Hipertróficas","Con Loe"],
      "Cuerda Vocal Derecha": ["Indemne","Indemne Móvil","Móvil Con Loe","Móvil Con Leucoplasia","Inmóvil Con Loe","Inmóvil Con Leucoplasia"],
      "Cuerda Vocal Izquierda": ["Indemne","Indemne Móvil","Móvil Con Loe","Móvil Con Leucoplasia","Inmóvil Con Loe","Inmóvil Con Leucoplasia"],
      "Subglotis": ["Permeable 100%","Estenosis Subglótica Cotton I","Estenosis Subglótica Cotton Ii","Estenosis Subglótica Cotton Iii"]
    },
    "Impedanciometría": {
      "Oído Derecho": ["Curva Tipo A","Curva Tipo As","Curva Tipo B","Curva Tipo C"],
      "Oído Izquierdo": ["Curva Tipo A","Curva Tipo As","Curva Tipo B","Curva Tipo C"]
    },
    "Tomografía de Oído": {
      "Cae Derecho": ["Permeable","No Permeable"],
      "Om Derecho": ["Neumatizado","Con Velamiento"],
      "Scutum Derecho": ["Indemne","Amputado"],
      "Co Derecha": ["Cadena Osicular Indemne","Cadena Osicular Alterada"],
      "Mastoides Derecha": ["Neumatizada","Poco Neumatizada","Velada Completamente"],
      "Cóclea Derecha": ["Indemne Con 2 Vueltas Y Media","Con Malformación","Impresiona","Osificada"],
      "Cai Derecho": ["Indemne","Hipoplásico","Con Loe"],
      "Cae Izquierdo": ["Permeable","No Permeable"],
      "Om Izquierdo": ["Neumatizado","Con Velamiento"],
      "Scutum Izquierdo": ["Indemne","Amputado"],
      "Co Izquierda": ["Cadena Osicular Indemne","Cadena Osicular Alterada"],
      "Mastoides Izquierda": ["Neumatizada","Poco Neumatizada","Velada Completamente"],
      "Cóclea Izquierda": ["Indemne Con 2 Vueltas Y Media","Con Malformación","Impresiona","Osificada"],
      "Cai Izquierdo": ["Indemne","Hipoplásico","Con Loe"]
    },
    "Tomografía de Nariz y SPN": {
      "Tabique": ["Central","Septumdesviación Levoconvexa","Septumdesviación Dextroconvexa","Espolón Óseo Derecho","Espolón Óseo Izquierdo"],
      "Cornetes": ["Eutróficos","Hipertróficos","Polipoides","Concha Media Bullosa Derecha","Concha Media Bullosa Izquierda","Cornete Medio Paradójico Derecho","Cornete Medio Paradójico Izquierdo"],
      "Meato Medio Derecho": ["Libre","Comprometido"],
      "Meato Medio Izquierdo": ["Libre","Comprometido"],
      "Coana Derecha": ["Permeable","No Permeable"],
      "Coana Izquierda": ["Permeable","No Permeable"],
      "Sinusopatía": ["Sin Sinusopatía","Con Sinusopatía Maxilar Derecha","Con Sinusopatía Maxilar Izquierda","Con Sinusopatía Frontal Derecha","Con Sinusopatía Frontal Izquierda","Con Sinusopatía Etmoidal Anterior Derecha","Con Sinusopatía Etmoidal Anterior Izquierda","Con Sinusopatía Etmoidal Posterior Derecha","Con Sinusopatía Etmoidal Posterior Izquierda","Con Sinusopatía Esfenoidal Anterior Derecha","Con Sinusopatía Esfenoidal Anterior Izquierda","Con Sinusopatía Maxiloetmoidal Derecha","Con Sinusopatía Maxiloetmoidal Izquierda"]
    }
  },
  PHYSICAL_EXAM: {
    "Cara": ["Simetría Facial","Asimetría Facial","Parálisis Facial Periférica","Parálisis Facial Periférica derecha","Parálisis Facial Periférica izquierda","Parálisis Facial Central","Edema Facial","Malformación Craneofacial"],
    "Oído Derecho": {
      "Oído Externo": ["Pabellón Auricular Indemne Normoimplantado","Microtia Grado 1","Microtia Grado 2","Microtia Grado 3","Anotia","Fístula"],
      "Conducto Auditivo Externo": ["CAE Libre","CAE con Otocerumen","CAE estenótico","Atresia CAE","CAE con LOE","CAE con Otorrea Fétida","CAE Descamativo"],
      "Membrana Timpánica": ["indemne, movilidad conservada","Opaca","abombada con líquido retrotimpánico escaso","abombada con líquido retrotimpánico que limita movilidad","eritematosa con líquido retrotimpático amarillento","con perforación anterior","con perforación posterior","con perforación central","con perforación amplia","con perforación puntiforme"]
    },
    "Oído Izquierdo": {
      "Oído Externo": ["Pabellón Auricular Indemne Normoimplantado","Microtia Grado 1","Microtia Grado 2","Microtia Grado 3","Anotia","Fístula"],
      "Conducto Auditivo Externo": ["CAE Libre","CAE con Otocerumen","CAE estenótico","Atresia CAE","CAE con LOE","CAE con Otorrea Fétida","CAE Descamativo"],
      "Membrana Timpánica": ["indemne, movilidad conservada","Opaca","abombada con líquido retrotimpánico escaso","abombada con líquido retrotimpánico que limita movilidad","eritematosa con líquido retrotimpático amarillento","con perforación anterior","con perforación posterior","con perforación central","con perforación amplia","con perforación puntiforme"]
    },
    "Nariz": {
      "Fosa": ["Fosa nasal permeable","LOE","LOE que obstruye compleamente fosa nasal izquierda","LOE que obstruye completamente fosa nasal derecha"],
      "Tabique": ["Tabique Central","con desviación Dextroconvexa","con desviación Levoconvexa","con espolón óseo"],
      "Cornetes": ["Cornete inferior eutrófico","Cornete inferior hipertrófico obstructivo","Cornete inferior con degeneración polipoidea","Cornete medio eutrófico","Cornete medio hipertrófico","Poliposis nasal"],
      "Mucosa": ["Mucosa Indemne","Mucosa Pálida","Mucosa Eritematosa a nivel de Plexos","Epistaxis Anterior","Epistaxis Posterior"],
      "Rinorrea": ["Rinorrea Hialina","Rinorrea Blanquecina","Rinorrea Amarillenta"]
    },
    "Orofaringe": {
      "Lengua": ["Lengua húmeda móvil","Lengua seca"],
      "Tonsilas": ["Tonsilas grado I","Tonsilas grado II","Tonsilas grado III","Tonsilas grado IV","Tonsilas asimétricas","Tonsilas con placas blanquecinas"],
      "Rinofaringe": ["Rinofaringe congestiva","con rinorrea posterior escasa","con rinorrea posterior blanquecina","con placas blanquecinas"]
    },
    "Cuello": ["Móvil, sin lesiones aparentes"]
  },
  ADDITIONAL_STUDIES: [
    "Audiometría", "Timpanometría", "Acufenometría", "Prueba de Prótesis Auditiva", "PEATC", "Estudio de Sueño", "Resonancia de Nariz y SPN", "Protocolo de Implante Coclear"
  ]
};

// ==========================================
// 3. TEMPLATE HTML
// ==========================================
const VISIT_TEMPLATE = (cardId, type, createdTime, createdBy, eaAuto, serviceId) => `
    ${STYLES}
    <div class="visit-header">
      <div style="flex: 1; display: flex; flex-direction: column; margin-left: 10px;">
          <div style="display:flex; align-items:center; gap:10px;">
             <span class="badge">${type}</span>
             <span style="font-weight:600;">Consulta ORL</span>
             <span style="background:rgba(255,255,255,0.1); padding:2px 6px; border-radius:4px; font-size:0.75em; color:var(--text-muted);">${serviceId}</span>
          </div>
          <div style="font-size: 10px; color: var(--text-muted); margin-top: 2px;">
             Creado: ${fmtDateTime(createdTime)} por ${createdBy}
          </div>
      </div>

      <div style="display: flex; gap: 10px;">
        <button type="button" class="btn btn-primary btn-small btn-docs"><i class="bi bi-file-text"></i> Documentos</button>
        <button type="button" class="btn btn-ghost btn-small text-danger btn-del-visit"><i class="bi bi-x-lg"></i></button>
        <button type="button" class="visit-toggle-btn btn btn-ghost btn-small"><i class="bi bi-chevron-down"></i></button>
      </div>
    </div>
    
    <div class="visit-body">
      <div class="row">
        <div class="col"><label class="form-label">Fecha y Hora</label><input type="datetime-local" class="form-input visit-date" value="${getLocalDateTime()}"></div>
      </div>
      <div class="form-section">
        <div class="form-section-title">1. Anamnesis</div>
        <div class="row"><div class="col"><label class="form-label">Motivo de Consulta</label><input class="form-input txt-motivo" placeholder="(texto libre)"><div class="chips chips-motivo" style="margin-top: 8px;"></div></div></div>
        <div class="row"><div class="col"><label class="form-label">Enfermedad Actual</label><textarea class="form-input txt-ea" rows="3" placeholder="(autogenerado)">${eaAuto}</textarea></div></div>
        <div class="row">
          <div class="col"><label class="form-label">Antecedentes Personales</label><input class="form-input txt-antecedentes-personales" placeholder="(se llena con chips)"><div class="chips chips-antecedentes-personales" style="margin-top: 8px;"></div></div>
          <div class="col"><label class="form-label">Antecedentes Familiares</label><input class="form-input txt-antecedentes-familiares" placeholder="(se llena con chips)"><div class="chips chips-antecedentes-familiares" style="margin-top: 8px;"></div></div>
        </div>
      </div>
      <div class="form-section">
        <div class="form-section-title">2. Examen Físico</div>
        <div class="exam-area"><div class="exam-area-title"><i class="bi bi-emoji-neutral"></i> Cara</div><label class="form-label">Hallazgos</label><input class="form-input txt-exam-cara" placeholder="Hallazgos..."><div class="chips chips-exam-cara" style="margin-top: 8px;"></div></div>
        <div class="exam-area"><div class="exam-area-title"><i class="bi bi-ear"></i> Oído Derecho</div><label class="form-label">Hallazgos</label><textarea class="form-input txt-exam-oido-derecho" rows="2" placeholder="Hallazgos..."></textarea><div class="chips-exam-oido-derecho" style="margin-top: 8px;"></div></div>
        <div class="exam-area"><div class="exam-area-title"><i class="bi bi-ear"></i> Oído Izquierdo</div><label class="form-label">Hallazgos</label><textarea class="form-input txt-exam-oido-izquierdo" rows="2" placeholder="Hallazgos..."></textarea><div class="chips-exam-oido-izquierdo" style="margin-top: 8px;"></div></div>
        <div class="exam-area"><div class="exam-area-title"><i class="bi bi-droplet"></i> Nariz</div><label class="form-label">Hallazgos</label><textarea class="form-input txt-exam-nariz" rows="2" placeholder="Hallazgos..."></textarea><div class="chips-exam-nariz" style="margin-top: 8px;"></div></div>
        <div class="exam-area"><div class="exam-area-title"><i class="bi bi-mic"></i> Orofaringe</div><label class="form-label">Hallazgos</label><textarea class="form-input txt-exam-orofaringe" rows="2" placeholder="Hallazgos..."></textarea><div class="chips-exam-orofaringe" style="margin-top: 8px;"></div></div>
        <div class="exam-area"><div class="exam-area-title"><i class="bi bi-person-standing"></i> Cuello</div><label class="form-label">Hallazgos</label><input class="form-input txt-exam-cuello" placeholder="Hallazgos..."><div class="chips chips-exam-cuello" style="margin-top: 8px;"></div></div>
      </div>
      <div class="form-section">
        <div class="form-section-title">3. Estudios</div>
        <div class="row"><div class="col"><label class="form-label">Seleccionar Estudios</label><div class="chips chips-studies" style="margin-top: 8px;"></div><div id="studies-content-${cardId}" style="margin-top: 16px;"></div></div></div>
      </div>
      <div class="form-section">
        <div class="form-section-title">4. Diagnóstico y Plan</div>
        <div class="row"><div class="col"><label class="form-label">Diagnóstico</label><input class="form-input txt-dx" placeholder="(se llena con chips + libre)"><div class="chips chips-dx" style="margin-top: 8px;"></div></div></div>
        <div class="row"><div class="col"><label class="form-label">Medicamentos / RP</label><textarea class="form-input txt-recipe" rows="4" placeholder="(seleccione medicamentos)"></textarea><div class="recipe-chips-container" style="margin-top: 8px;"></div></div></div>
        <div class="row"><div class="col"><label class="form-label">Indicaciones (Posología)</label><div class="indicaciones-dropdowns" style="margin-bottom: 10px;"></div><textarea class="form-input txt-indicaciones" rows="6" placeholder="(se generan automáticamente)"></textarea></div></div>
        <div class="row"><div class="col"><label class="form-label">Plan / Tratamiento Final</label><textarea class="form-input txt-plan" rows="8" placeholder="(hereda de indicaciones + texto legal)"></textarea></div></div>
      </div>
      <div class="patient-nav">
        <button type="button" class="btn btn-ghost btn-small" onclick="document.getElementById('${cardId}').scrollIntoView({behavior: 'smooth'})"><i class="bi bi-arrow-up"></i> Subir</button>
        <button type="button" class="btn btn-ghost btn-small btn-collapse-card"><i class="bi bi-arrows-collapse"></i> Colapsar</button>
      </div>
    </div>
`;

// ==========================================
// 4. LOGICA DEL COMPONENTE (ENGINE)
// ==========================================
function createChip(label, type = 'normal') {
    const s = document.createElement('span');
    s.className = 'chip' + (type.includes('study') ? ' study-chip' : '');
    s.textContent = label;
    s.dataset.active = '0';
    s.addEventListener('click', () => {
        const isActive = s.dataset.active === '1';
        s.dataset.active = isActive ? '0' : '1';
        s.classList.toggle('on', !isActive);
        s.dispatchEvent(new CustomEvent('chip-toggle', { bubbles: true, detail: { label, active: !isActive } }));
    });
    return s;
}

function createChipGroup(title, items, container) {
    const groupDiv = document.createElement('div');
    groupDiv.className = 'chip-group';
    groupDiv.innerHTML = `<div class="chip-group-title">${title}</div><div class="chips"></div>`;
    const chipsDiv = groupDiv.querySelector('.chips');
    items.forEach(item => chipsDiv.appendChild(createChip(item)));
    container.appendChild(groupDiv);
}

export function createVisitCard(type = 'Primera') {
    STATE.visitIdCounter++;
    const cardId = 'visit-' + STATE.visitIdCounter;
    const serviceId = generateServiceId();
    let createdBy = 'Usuario';
    if(STATE.currentUser?.profile?.firstname) {
        createdBy = STATE.currentUser.profile.firstname + ' ' + (STATE.currentUser.profile.lastname || '');
    }
    const createdTime = new Date().toISOString();

    const wrap = document.createElement('div');
    wrap.id = cardId;
    wrap.className = 'card visit-card';
    wrap.dataset.type = type;
    wrap.dataset.createdBy = createdBy;
    wrap.dataset.createdAt = createdTime;
    wrap.dataset.serviceId = serviceId; 

    const edad = $("#edad_auto")?.value || '';
    const genero = $("#genero")?.value || '';
    const edadStr = (edad || edad === 0) ? `${edad} años` : '[edad]';
    const eaAuto = `Paciente ${genero || '[género]'} de ${edadStr} quien acude a consulta por presentar [Motivo de consulta].`;

    wrap.innerHTML = VISIT_TEMPLATE(cardId, type, createdTime, createdBy, eaAuto, serviceId);

    // ============================
    // HERENCIA DE DATOS
    // ============================
    const existingCards = Array.from(document.querySelectorAll('.visit-card'));
    
    if (existingCards.length === 0) {
        // CASO 1: PRIMERA CONSULTA -> HEREDA DE FICHA PACIENTE
        try {
            const patientData = ServiceLoader.get('patient').getPatientData();
            let antecedentes = [];
            
            // Mapeo directo de checks a texto
            if (patientData.alergias_check) antecedentes.push("Alergias: " + (patientData.alergias_detalle || ''));
            if (patientData.diabetes_check) antecedentes.push("Diabetes");
            if (patientData.asma_check) antecedentes.push("Asma");
            if (patientData.cardiopatias_check) antecedentes.push("Cardiopatía");
            if (patientData.epilepsia_check) antecedentes.push("Epilepsia");
            if (patientData.tiroideos_check) antecedentes.push("Tiroides");
            if (patientData.cronicas_check) antecedentes.push("Crónicas: " + (patientData.cronicas_detalle || ''));
            if (patientData.otros_antecedentes) antecedentes.push(patientData.otros_antecedentes);

            const txtAntPers = wrap.querySelector('.txt-antecedentes-personales');
            if (txtAntPers) txtAntPers.value = antecedentes.join(', ');

            let familiares = [];
            if (patientData.familia_hipertension) familiares.push('HTA');
            if (patientData.familia_diabetes) familiares.push('DM');
            if (patientData.familia_cardiopatias) familiares.push('Cardiopatía');
            if (patientData.familia_cancer) familiares.push('Cáncer');
            if (patientData.familia_geneticas) familiares.push(patientData.familia_geneticas);
            
            const txtAntFam = wrap.querySelector('.txt-antecedentes-familiares');
            if (txtAntFam) txtAntFam.value = familiares.join(', ');
        } catch(e) { console.warn("No se pudo heredar del paciente", e); }

    } else {
        // CASO 2: SUCESIVA -> HEREDA DE CONSULTA ANTERIOR
        const prevCard = existingCards[0]; 
        const fieldsToCopy = [
            '.txt-antecedentes-personales', '.txt-antecedentes-familiares',
            '.txt-motivo', '.txt-ea',
            '.txt-exam-cara', '.txt-exam-oido-derecho', '.txt-exam-oido-izquierdo',
            '.txt-exam-nariz', '.txt-exam-orofaringe', '.txt-exam-cuello'
        ];
        fieldsToCopy.forEach(selector => {
            const prevVal = prevCard.querySelector(selector)?.value;
            const currInput = wrap.querySelector(selector);
            if (prevVal && currInput) currInput.value = prevVal;
        });
    }

    // --- LOGICA DE EVENTOS (BUTTONS FIX) ---
    // 1. Header Toggle (Click en toda la barra)
    const header = wrap.querySelector('.visit-header');
    header.addEventListener('click', () => {
        const body = wrap.querySelector('.visit-body');
        const icon = header.querySelector('.visit-toggle-btn i');
        body.classList.toggle('hidden');
        icon.className = body.classList.contains('hidden') ? 'bi bi-chevron-right' : 'bi bi-chevron-down';
    });

    // 2. Botones específicos (Prevent bubble)
    wrap.querySelector('.btn-docs').addEventListener('click', (e) => {
        e.stopPropagation();
        window.openDocGlobal('INF', cardId);
    });

    wrap.querySelector('.btn-del-visit').addEventListener('click', (e) => {
        e.stopPropagation();
        if(confirm('¿Eliminar esta consulta?')) wrap.remove();
    });

    wrap.querySelector('.visit-toggle-btn').addEventListener('click', (e) => {
        e.stopPropagation();
        header.click(); // Delega al header
    });
    
    wrap.querySelector('.btn-collapse-card').addEventListener('click', (e) => {
        e.stopPropagation();
        const body = wrap.querySelector('.visit-body');
        body.classList.add('hidden');
        wrap.querySelector('.visit-toggle-btn i').className = 'bi bi-chevron-right';
    });

    // --- INYECCIÓN DE CHIPS (Igual que antes) ---
    const motivoContainer = wrap.querySelector('.chips-motivo');
    CIMA_DATA.MOTIVOS.forEach(m => motivoContainer.appendChild(createChip(m)));
    const antPersContainer = wrap.querySelector('.chips-antecedentes-personales');
    const antFamContainer = wrap.querySelector('.chips-antecedentes-familiares');
    CIMA_DATA.ANTECEDENTES.forEach(a => antPersContainer.appendChild(createChip(a)));
    CIMA_DATA.ANTECEDENTES.forEach(a => antFamContainer.appendChild(createChip(a)));
    
    const caraContainer = wrap.querySelector('.chips-exam-cara');
    CIMA_DATA.PHYSICAL_EXAM.Cara.forEach(i => caraContainer.appendChild(createChip(i)));
    const cuelloContainer = wrap.querySelector('.chips-exam-cuello');
    CIMA_DATA.PHYSICAL_EXAM.Cuello.forEach(i => cuelloContainer.appendChild(createChip(i)));

    const odContainer = wrap.querySelector('.chips-exam-oido-derecho');
    Object.entries(CIMA_DATA.PHYSICAL_EXAM["Oído Derecho"]).forEach(([group, items]) => createChipGroup(group, items, odContainer));
    const oiContainer = wrap.querySelector('.chips-exam-oido-izquierdo');
    Object.entries(CIMA_DATA.PHYSICAL_EXAM["Oído Izquierdo"]).forEach(([group, items]) => createChipGroup(group, items, oiContainer));
    const narizContainer = wrap.querySelector('.chips-exam-nariz');
    Object.entries(CIMA_DATA.PHYSICAL_EXAM.Nariz).forEach(([group, items]) => createChipGroup(group, items, narizContainer));
    const oroContainer = wrap.querySelector('.chips-exam-orofaringe');
    Object.entries(CIMA_DATA.PHYSICAL_EXAM.Orofaringe).forEach(([group, items]) => createChipGroup(group, items, oroContainer));

    const studiesContainer = wrap.querySelector('.chips-studies');
    Object.keys(CIMA_DATA.STUDIES).forEach(studyName => studiesContainer.appendChild(createChip(studyName, 'study-complex')));
    CIMA_DATA.ADDITIONAL_STUDIES.forEach(studyName => studiesContainer.appendChild(createChip(studyName, 'study-simple')));

    const dxContainer = wrap.querySelector('.chips-dx');
    CIMA_DATA.DX.forEach(d => dxContainer.appendChild(createChip(d)));

    const recipeContainer = wrap.querySelector('.recipe-chips-container');
    Object.entries(CIMA_DATA.RECIPE_MEDS).forEach(([group, meds]) => {
        const groupDiv = document.createElement('div');
        groupDiv.style.marginBottom = '12px'; groupDiv.className = 'recipe-chips-group'; groupDiv.dataset.group = group; 
        groupDiv.innerHTML = `<div style="font-weight: 600; color: var(--accent); margin: 8px 0;">${group}</div><div class="chips"></div>`;
        const chipsBox = groupDiv.querySelector('.chips');
        meds.forEach(med => chipsBox.appendChild(createChip(med)));
        recipeContainer.appendChild(groupDiv);
    });

    // Chip logic listeners
    wrap.addEventListener('chip-toggle', (e) => {
        const { label, active } = e.detail;
        const target = e.target;

        if (target.closest('.chips-studies')) {
            const contentArea = wrap.querySelector(`#studies-content-${cardId}`);
            const uniqueId = `study-${label.replace(/\s+/g, '-')}-${cardId}`;
            if (active) {
                const studyDiv = document.createElement('div');
                studyDiv.id = uniqueId; studyDiv.className = 'study-content';
                studyDiv.style.cssText = "margin-bottom:15px; padding:10px; background:rgba(59,130,246,0.05); border-left:3px solid var(--primary);";
                let innerHTML = `<div style="font-weight:700; margin-bottom:5px; color:var(--text-main);">${label}</div><textarea class="form-input txt-study-result" rows="3" placeholder="Resultados de ${label}..."></textarea>`;
                if (CIMA_DATA.STUDIES[label]) innerHTML += `<div class="study-sub-chips" style="margin-top:10px;"></div>`;
                studyDiv.innerHTML = innerHTML;
                contentArea.appendChild(studyDiv);
                if (CIMA_DATA.STUDIES[label]) {
                    const subContainer = studyDiv.querySelector('.study-sub-chips');
                    Object.entries(CIMA_DATA.STUDIES[label]).forEach(([groupTitle, items]) => createChipGroup(groupTitle, items, subContainer));
                }
            } else { const el = document.getElementById(uniqueId); if (el) el.remove(); }
        }

        if (target.closest('.study-sub-chips')) {
            const studyDiv = target.closest('.study-content');
            const textarea = studyDiv.querySelector('textarea');
            const activeSubChips = Array.from(studyDiv.querySelectorAll('.chip.on'));
            const grouped = {};
            activeSubChips.forEach(c => {
                const group = c.closest('.chip-group').querySelector('.chip-group-title').textContent;
                if(!grouped[group]) grouped[group] = [];
                grouped[group].push(c.textContent);
            });
            let text = "";
            Object.entries(grouped).forEach(([g, i]) => { text += `${g}: ${i.join(', ')}\n`; });
            textarea.value = text;
        }

        const simpleInputs = [{ cont: '.chips-motivo', input: '.txt-motivo' },{ cont: '.chips-dx', input: '.txt-dx' },{ cont: '.chips-antecedentes-personales', input: '.txt-antecedentes-personales' },{ cont: '.chips-antecedentes-familiares', input: '.txt-antecedentes-familiares' },{ cont: '.chips-exam-cara', input: '.txt-exam-cara' },{ cont: '.chips-exam-cuello', input: '.txt-exam-cuello' }];
        simpleInputs.forEach(item => {
            if (target.closest(item.cont)) {
                const chips = Array.from(wrap.querySelectorAll(`${item.cont} .chip.on`));
                const input = wrap.querySelector(item.input);
                if (input && !input.dataset.userEdited) input.value = chips.map(c => c.textContent).join(', ');
            }
        });

        const groupedExamInputs = [{ cont: '.chips-exam-oido-derecho', input: '.txt-exam-oido-derecho' },{ cont: '.chips-exam-oido-izquierdo', input: '.txt-exam-oido-izquierdo' },{ cont: '.chips-exam-nariz', input: '.txt-exam-nariz' },{ cont: '.chips-exam-orofaringe', input: '.txt-exam-orofaringe' }];
        groupedExamInputs.forEach(item => {
            if (target.closest(item.cont)) {
                const input = wrap.querySelector(item.input);
                if (input && !input.dataset.userEdited) {
                    const chips = Array.from(wrap.querySelectorAll(`${item.cont} .chip.on`));
                    const grouped = {};
                    chips.forEach(c => {
                        const g = c.closest('.chip-group').querySelector('.chip-group-title').textContent;
                        if(!grouped[g]) grouped[g] = [];
                        grouped[g].push(c.textContent);
                    });
                    let text = "";
                    Object.entries(grouped).forEach(([g, i]) => { text += `${g}: ${i.join(', ')}\n`; });
                    input.value = text.trim();
                }
            }
        });

        if (target.closest('.recipe-chips-container')) {
            updateRecipeTextbox(wrap);
            renderIndicacionesDropdowns(wrap);
        }
    });

    wrap.querySelectorAll('textarea, input[type="text"]').forEach(input => {
        input.addEventListener('input', () => input.dataset.userEdited = '1');
    });

    return wrap;
}
